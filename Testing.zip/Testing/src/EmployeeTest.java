import static org.junit.Assert.*;

import org.junit.Test;

public class EmployeeTest {
	@Test
	public void testcalNetPay1() {
		Employee emp = new Employee(102, "vijay", 1000, 5);
		double actual = emp.calNetPay();
		double expected = 1000;
		assertTrue(expected == actual);
	}

	@Test
	public void testcalNetPay2() {
		// creating another employee object
		Employee emp = new Employee(100, "vijay", 1000, 7);
		double actual = emp.calNetPay();
		double expected = 930;
		assertTrue(expected == actual);
	}

	@Test
	public void testcalNetPay3() {
		Employee emp = new Employee(100, "vijay", 1000, 10);
		double Actual = emp.calNetPay();
		double Expected = 900;
		assertTrue(Expected == Actual);
	}
}
